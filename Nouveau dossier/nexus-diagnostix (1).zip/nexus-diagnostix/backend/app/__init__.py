"""Nexus-Diagnostix — backend FastAPI."""

__version__ = "1.0.0"
