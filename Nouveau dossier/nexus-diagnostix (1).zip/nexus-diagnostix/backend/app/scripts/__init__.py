"""Scripts utilitaires."""
